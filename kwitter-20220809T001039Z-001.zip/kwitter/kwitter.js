var firebaseConfig = {
    apiKey: "AIzaSyCj-6slxpCKGtcGKwYVjGw9wmhvs-2Z5pM",
    authDomain: "class94-45060.firebaseapp.com",
    databaseURL: "https://class94-45060-default-rtdb.firebaseio.com",
    projectId: "class94-45060",
    storageBucket: "class94-45060.appspot.com",
    messagingSenderId: "323309235154",
    appId: "1:323309235154:web:810977313490b949b5b60b"
  };
firebase.initializeApp(firebaseConfig); 


function addUser(){
Username=document.getElementById("Username").value;
localStorage.setItem("Username", Username);
window.location="kwitter_room.html";
}
