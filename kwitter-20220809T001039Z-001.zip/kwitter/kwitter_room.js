
//ADD YOUR FIREBASE LINKS HERE
var firebaseConfig = {
      apiKey: "AIzaSyCj-6slxpCKGtcGKwYVjGw9wmhvs-2Z5pM",
      authDomain: "class94-45060.firebaseapp.com",
      databaseURL: "https://class94-45060-default-rtdb.firebaseio.com",
      projectId: "class94-45060",
      storageBucket: "class94-45060.appspot.com",
      messagingSenderId: "323309235154",
      appId: "1:323309235154:web:810977313490b949b5b60b"
    };
    firebase.initializeApp(firebaseConfig); 
    user_name=localStorage.getItem("user_name");
    document.getElementById("user_name").innerHTML="Welcome" + user_name + "!";
    function addRoom(){
      room_name=docment.getElementById("room_name").value;
      firebase.database().ref("/").child(room_name).update({purpose:"Adding Room Name"});
      localStorage.setItem("room_name", room_name);
      window.location="kwitter_page.html"
    }


function getData() {firebase.database().ref("/").on('value', function(snapshot) {document.getElementById("output").innerHTML = "";snapshot.forEach(function(childSnapshot) {childKey  = childSnapshot.key;
       Room_names = childKey;
      //Start code
      console.log("room_name "+room_name);
      row = "<div class='room_name' id="+Room_names+" onclick='redirectToRoomName(this.id)' >#"+ Room_names +"</div><hr>";
document.getElementById("output").innerHTML+=row;
      //End code
      });});}
getData();
